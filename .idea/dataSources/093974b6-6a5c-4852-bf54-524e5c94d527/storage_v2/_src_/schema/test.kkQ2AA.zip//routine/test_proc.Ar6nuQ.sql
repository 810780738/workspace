create procedure test_proc()
  begin
    /*声明一个标志done，用来判断游标是否遍历完成*/
    declare done int default 0;
    /*声明一个变量，用来存放从游标中提取的数据*/
    /*特别注意这里的名字不能与游标中使用的列明相同，否则得到的数据都是null*/
    declare tname varchar(50) default null ;
    declare tpass varchar(50) default null ;

    /*声明游标对应的SQL语句*/
    declare cur cursor for
      select NAME,PASSWORD from NETINGCN_PROC_TEST;
    /*游标循环到最后将done设置为 1*/
    declare continue  handler for not found set done=1;

    /*执行查询*/
    open cur;
    /*遍历游标每一行*/
    repeat
      /*把一行的信息放到对应的变量中*/
      fetch cur into tname,tpass;
      if not done then
          select tname,tpass;
      end if;
    until done end repeat;
    close cur;
  end;

