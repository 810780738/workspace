create procedure inspect_name()
  begin
    select name from NETINGCN_PROC_TEST where ID=1;
    if name > 0 then
      select COUNT(1) from NETINGCN_PROC_TEST;
    end if;

  end;

