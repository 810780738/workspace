create function getOrgName(org_Id varchar(255))
  returns varchar(255)
  BEGIN
DECLARE orgName VARCHAR (255) ; SELECT
	fullName INTO orgName
FROM
	base_orgmain
WHERE
	orgId = org_Id ; RETURN orgName ;
END;

