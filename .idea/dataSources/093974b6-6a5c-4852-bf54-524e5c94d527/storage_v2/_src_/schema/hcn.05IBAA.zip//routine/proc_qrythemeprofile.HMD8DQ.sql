create procedure proc_qryThemeProfile(IN serviceRecordId varchar(32), IN targetType varchar(3))
  BEGIN
  IF(targetType='031')
  THEN
	SELECT ps.exeId,md.dob,md.sex,(SELECT od.consultRecordId FROM ods_picturetextconsult od WHERE od.serviceRecordId=serviceRecordId ORDER BY od.operateTime LIMIT 1) refRecordId,CONCAT('0',ps.status),ps.lastModifyDt,ps.lastModifyUser,pt.memberObjId targetId
    FROM pcn_service_exec ps LEFT JOIN mpi_demographicinfo md ON ps.mpiId=md.mpiId 
    LEFT JOIN pcn_team_member pt ON ps.exeUserId=pt.memberId
    WHERE ps.exeId=serviceRecordId;
  ELSE
    SELECT ps.exeId,md.dob,md.sex,(SELECT od.consultRecordId FROM ods_picturetextconsult od WHERE od.serviceRecordId=serviceRecordId ORDER BY od.operateTime LIMIT 1) refRecordId,CONCAT('0',ps.status),ps.lastModifyDt,ps.lastModifyUser,ps.mpiId targetId
    FROM pcn_service_exec ps LEFT JOIN mpi_demographicinfo md ON ps.mpiId=md.mpiId 
    WHERE ps.exeId=serviceRecordId;
  END IF;  
END;

