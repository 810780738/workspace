create function getDocFileId(doctor_Id varchar(255))
  returns int
  BEGIN
DECLARE fileId INT ; SELECT
	avatarFileId INTO fileId
FROM
	doct_info
WHERE
	doctorId = doctor_Id ; RETURN fileId ;
END;

