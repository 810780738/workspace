create procedure sub_signappky(IN cycleCount int)
  BEGIN
  DECLARE cycleIndex INT;
  DECLARE nid INT;
   
  SET cycleIndex = 0;
  WHILE cycleIndex < cycleCount  DO
     SET cycleIndex = cycleIndex + 1;
     INSERT INTO pcn_signapply(tenantId,mpiId,socialSecurityNo,tel,doctorId,localDoctorId,teamId,orgId,localOrgId,personGroup,signCycle,protocolId,STATUS,applyUser,applyDt)
     VALUES('zhongshan','bc47a9c0c3a441c4b89dfc704f73c411','TO_DELETE','100000','12aded57-121d-4c19-86ce-942935795327','',2,'b4c00af4-e803-4e52-9406-43c02366aac1','','',1,NULL,1,'bc47a9c0c3a441c4b89dfc704f73c411',NOW());
     
     SELECT LAST_INSERT_ID() INTO nid;
     
     INSERT INTO pcn_applypack(applyId,tenantId,serviceId,serviceName,price,serviceDesc)
     values(nid,'zhongshan',8,'免费包',0,'TO_DELETE');
     
  END WHILE;  
  
END;

