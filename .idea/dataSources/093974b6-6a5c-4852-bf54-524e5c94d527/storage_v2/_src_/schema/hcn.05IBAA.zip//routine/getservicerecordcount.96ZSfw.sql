create function getServiceRecordCount(tenantId varchar(32), mpiId varchar(32), qryDate datetime, finishedOnly int)
  returns int
  BEGIN
 DECLARE serviceCount INT; 
 DECLARE startDate DATETIME;
 DECLARE endDate DATETIME;
 
  SELECT ps.beginDate,ps.endDate INTO startDate,endDate 
  FROM pcn_sign ps WHERE ps.mpiId = mpiId AND (ps.isCancel IS NULL OR ps.isCancel <> '1') AND qryDate BETWEEN ps.beginDate AND ps.endDate; 
  IF(finishedOnly=1)
  THEN
   SELECT COUNT(1) INTO serviceCount FROM pcn_service_exec ps WHERE ps.tenantId=tenantId AND ps.mpiId=mpiId AND DATEDIFF(ps.exeDt,startDate)>=0 AND ps.`status`='08'; -- 不同模块公用服务项目次数而注释 AND EXISTS(SELECT od.serviceRecordId FROM ods_picturetextconsult od WHERE od.serviceRecordId=ps.exeId LIMIT 1) 
  ELSE
   SELECT COUNT(1) INTO serviceCount FROM pcn_service_exec ps WHERE ps.tenantId=tenantId  AND  ps.mpiId=mpiId AND DATEDIFF(ps.exeDt,startDate)>= 0;-- 不同模块公用服务项目次数而注释 AND EXISTS(SELECT od.serviceRecordId FROM ods_picturetextconsult od WHERE od.serviceRecordId=ps.exeId LIMIT 1)
  END IF;
RETURN serviceCount;
END;

