create function getIdType(id_Card varchar(255))
  returns varchar(255)
  BEGIN
DECLARE id_Type VARCHAR (255) ; SELECT
	idType INTO id_Type
FROM
	mpi_identity
WHERE
	idOrNo = id_Card ; RETURN id_Type ;
END;

