create procedure proc_qryExtChatRecordData(IN  serviceRecordId int, OUT rtnCode int, OUT rtnMsg varchar(100),
                                           OUT signId          int, OUT teamId int)
  BEGIN
  SET rtnCode=1;
  SELECT ps.teamId,psrp.signId INTO teamId,signId 
  FROM pcn_service_exec ps ,pcn_sign_resident_pack psrp 
  WHERE ps.exeId=serviceRecordId AND psrp.signPackId=ps.signPackId;
END;

