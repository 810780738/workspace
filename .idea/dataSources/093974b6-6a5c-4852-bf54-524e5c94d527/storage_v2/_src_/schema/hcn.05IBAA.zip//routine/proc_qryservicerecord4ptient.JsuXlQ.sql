create procedure proc_qryServiceRecord4Ptient(IN tenantId      varchar(32), IN targetId varchar(36),
                                              IN participantId varchar(36), IN stateText varchar(36), IN startIndex int,
                                              IN pageSize      int)
  BEGIN
   DECLARE serviceRecordId INT;
   DECLARE avatarId INT;
   DECLARE mpiId VARCHAR(32);
   DECLARE age VARCHAR(20);
   DECLARE sex CHAR(1);
   DECLARE pubUserName VARCHAR(20);
 
   DECLARE done INT DEFAULT 0; -- 遍历数据结束标志   
  
   DECLARE cursor_ps_serviceexe CURSOR FOR  -- 声明游标
   SELECT ps.exeId serviceRecordId,ps.mpiId
   FROM pcn_service_exec ps 
   WHERE ps.tenantId=tenantId AND stateText LIKE CONCAT('%',ps.status,',%') AND EXISTS(SELECT ptm.memberId FROM pcn_team_member ptm WHERE ptm.memberType='doctor' AND ptm.teamId=ps.teamId AND ptm.memberObjId=targetId)
      AND (participantId ='' OR (participantId <>'' AND (ps.mpiId=participantId OR ps.createUser=participantId) ))
   ORDER BY ps.exeDt DESC
   LIMIT startIndex,pageSize;
   
   DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1; -- 将结束标志绑定到游标
   -- 临时表，存储....  
   DROP TEMPORARY TABLE IF EXISTS `table_service_target`;
   CREATE TEMPORARY TABLE table_service_target(serviceRecordId INT,targetType VARCHAR(3),targetId VARCHAR(36),displayName VARCHAR(20),avatarId INT,refRecordId INT,pubUserId VARCHAR(32),sex CHAR(1),age VARCHAR(20));
   -- 打开游标
   OPEN cursor_ps_serviceexe;
  
   
     -- 开始循环
     read_loop: LOOP
       -- 提取游标里的数据，这里只有一个，多个的话也一样；
       FETCH cursor_ps_serviceexe INTO serviceRecordId,mpiId;
       -- 声明结束的时候
       IF (done=1) THEN
         LEAVE read_loop;
       END IF;
       -- 这里做你想做的循环的事件
       
       SELECT md.dob,md.sex,md.personName,md.avatar INTO age,sex,pubUserName,avatarId FROM mpi_demographicinfo md WHERE md.mpiId=mpiId;
       INSERT INTO table_service_target(serviceRecordId,targetType,targetId,displayName,avatarId,refRecordId,pubUserId,sex,age)
       VALUES(serviceRecordId,'041',mpiId,pubUserName,avatarId,(SELECT dp.consultRecordId FROM ods_picturetextconsult dp WHERE dp.serviceRecordId = serviceRecordId ORDER BY dp.operateTime ASC LIMIT 0,1),'',sex,age);
     END LOOP;
     -- 关闭游标
     CLOSE cursor_ps_serviceexe; 
     
     SELECT tt.*,ps.lastModifyUser,ps.lastModifyDt endDate,ps.exeDt dispayTime,ps.exeDesc displayText,CONCAT('0',ps.status)  FROM table_service_target tt 
     LEFT JOIN pcn_service_exec ps ON ps.exeId=tt.serviceRecordId ORDER BY ps.exeDt DESC ;
  COMMIT; 
END;

