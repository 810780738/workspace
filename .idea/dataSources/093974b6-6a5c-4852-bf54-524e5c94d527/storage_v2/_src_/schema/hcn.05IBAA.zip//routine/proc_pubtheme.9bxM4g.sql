create procedure proc_pubTheme(IN  tenantId    varchar(32), IN serviceCountLimitConfig char, IN mpiId varchar(32),
                               IN  memberId    varchar(32), IN doctorId varchar(36), IN todayDate datetime,
                               IN  serviceDesc varchar(500), IN exeWay char, IN source char, IN relationId varchar(100),
                               IN  contentType char(2), IN voiceImageFile int, IN pictureFileIdString varchar(100),
                               OUT rtnCode     int, OUT rtnMsg varchar(100), OUT serviceRecordId int)
  BEGIN
  DECLARE startDate DATETIME;
  DECLARE endDate DATETIME;
  DECLARE signId INT;
  DECLARE packId INT;
  DECLARE serviceId INT;
  DECLARE spPackId INT;
  DECLARE spServiceId INT;
  DECLARE signPackId INT;
  DECLARE signServiceId INT;
  DECLARE objId INT;
  DECLARE spPackName VARCHAR(100);
  DECLARE execUserId VARCHAR(32);
  DECLARE serviceName VARCHAR(100);
  DECLARE localDoctorId VARCHAR(32);
  DECLARE spType VARCHAR(10);
  DECLARE spId VARCHAR(64);
  DECLARE spName VARCHAR(100);
  DECLARE teamId INT;
  DECLARE orgId VARCHAR(36);
  DECLARE localOrgId VARCHAR(32); 
  DECLARE patientName VARCHAR(30);
  DECLARE createUserName VARCHAR(30);
  DECLARE patientAvatar INT; 
  DECLARE doctorName VARCHAR(30);
  DECLARE doctorAvatar INT; 
  DECLARE serviceCount INT; 
  DECLARE serviceCountLimit INT; 
  -- DECLARE serviceCountLimitConfig VARCHAR(200); 
  DECLARE flag INT; 
 
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
   SET rtnCode=100101;
   SET rtnMsg='数据库操作异常';
  END;
  
  SET flag=1;  
  SET rtnCode=1;
  SET rtnMsg='操作成功';
  
  IF (memberId <> '')
  THEN
    SET execUserId=memberId;
  ELSE
    SET execUserId=mpiId;
  END IF;
  
  SELECT ps.signId,ps.teamId,ps.beginDate,ps.endDate,ps.localDoctorId,ps.orgId,ps.localOrgId INTO signId,teamId,startDate,endDate,localDoctorId,orgId,localOrgId 
  FROM pcn_sign ps WHERE EXISTS(SELECT pt.memberId FROM pcn_team_member pt WHERE pt.teamId=ps.teamId AND pt.memberType='doctor' AND pt.isEnable=1) -- AND pt.memberObjId=doctorId 
     AND ps.mpiId = execUserId AND (ps.isCancel IS NULL OR ps.isCancel <> '1') AND  DATEDIFF(todayDate, ps.beginDate) >= 0 ;
  -- SELECT bsp.exPropertyData INTO serviceCountLimitConfig FROM base_service bs  -- 咨询互动服务属性配置值，是否限制次数
  -- LEFT JOIN base_serviceopen bso ON bso.serviceId=bs.serviceId 
  -- LEFT JOIN base_serviceproperty bsp ON bso.id=bsp.openserviceId AND bsp.effectiveFlag='1' 
  -- WHERE bs.serviceType='02' AND bs.serviceCode='0202' AND bs.effectiveFlag='1' AND bso.effectiveFlag='1' AND bso.cloudId=tenantId AND bsp.effectiveFlag='1' AND bsp.exPropertyCode='020201'  ;
  
  IF(serviceCountLimitConfig='1')
  THEN
    SET serviceCount=getServiceRecordCount(tenantId,@execUserId,startDate,0); -- 咨询服务总数  
    SET serviceCountLimit=getServiceCountLimit(tenantId,@execUserId,todayDate); -- 已使用次数  
  END IF;
  
  IF(serviceCountLimitConfig='1' AND 0=serviceCountLimit)
  THEN
   SET rtnCode=100008;
   SET rtnMsg='签约服务次数为0';
   SET flag=0;
  ELSEIF(serviceCountLimitConfig='1' AND  serviceCount>=serviceCountLimit)
  THEN
   SET rtnCode=100009;
   SET rtnMsg='服务次数已用完';
   SET flag=0; 
  ELSE    
    SELECT psrp.spPackId,pss.spServiceId,psrp.signPackId,pss.signServiceId,psrp.spPackName,pss.serviceId,pss.serviceName
    INTO spPackId,spServiceId,signPackId,signServiceId,spPackName,serviceId,serviceName -- 服务商服务包ID、服务商服务项ID、签约服务包ID、签约服务项ID、服务商服务包名称、服务项目id、服务项目名称
    FROM pcn_sign_service pss,pcn_sign_resident_pack psrp
    WHERE psrp.signPackId=pss.signPackId AND psrp.signId=signId AND pss.remainTimes>0 
     AND EXISTS(
       SELECT pbs.serviceId FROM pcn_base_service pbs WHERE pbs.serviceCode=pss.serviceCode AND pbs.correlation LIKE '%30%' 
      )
    ORDER BY pss.startDate LIMIT 1;
  END IF; 
  
  IF (flag=0)
  THEN
   SET flag=0;
  ELSEIF (signId IS NULL)
  THEN 
   SET rtnCode=100001;
   SET rtnMsg='没有有效的签约信息';
   SET flag=0;
  ELSEIF (teamId IS NULL)
  THEN 
   SET rtnCode=100002;
   SET rtnMsg='团队信息不存在';
   SET flag=0;
  ELSEIF (serviceId IS NULL)
  THEN 
   SET rtnCode=100003;
   SET rtnMsg='服务信息不存在';
   SET flag=0;
  ELSEIF (startDate IS NULL)
  THEN 
   SET rtnCode=100004;
   SET rtnMsg='签约起始日期缺失';
   SET flag=0;
  ELSEIF (endDate IS NULL)
  THEN 
   SET rtnCode=100005;
   SET rtnMsg='签约截止日期缺失';
   SET flag=0;
  ELSE
    SELECT md.personName,md.avatar INTO patientName,patientAvatar FROM mpi_demographicinfo md WHERE md.mpiId = execUserId; -- 查询患者名称、头像
    SELECT dt.name,dt.avatarFileId INTO doctorName,doctorAvatar FROM doct_info dt WHERE dt.doctorId = doctorId;   -- 查询医生名称、头像
    SELECT pm.memberId INTO objId FROM pcn_team_member pm WHERE pm.teamId=teamId AND pm.memberObjId=doctorId AND pm.memberType='doctor' LIMIT 1;   -- 查询成员ID
  END IF;   
  IF(flag=1 AND mpiId=execUserId)
  THEN  
    SELECT md.personName INTO createUserName FROM mpi_demographicinfo md WHERE md.mpiId = mpiId;
  ELSE
    SET createUserName=patientName;
  END IF;
  
  IF(flag=0)
  THEN  
   SET flag=0;
  ELSEIF (doctorName IS NULL)
  THEN 
   SET rtnCode=100006;
   SET rtnMsg='医生姓名不完整';
   SET flag=0;
  ELSEIF(patientName IS NULL)
  THEN 
   SET rtnCode=100007;
   SET rtnMsg='患者姓名为空';
   SET flag=0;
  ELSE  -- ,spPackId,spServiceId                spPackId,spServiceId, createUser--发布者，未必是签约者，可能是签约者的家长
   IF(serviceCountLimitConfig='1')
   THEN
     UPDATE pcn_sign_service pss SET pss.remainTimes=pss.remainTimes-1 WHERE pss.signServiceId=signServiceId; -- 更新签约服务项目记录中的剩余次数
   END IF;
   INSERT INTO pcn_service_exec(tenantId,signPackId,signServiceId,spPackId,spServiceId,spPackName,serviceId,serviceName,mpiId,personName,exeUserType,exeUserId,exeUserName,teamId,exeDt,exeDesc,orgId,localOrgId,exeWay,source,evaluateFalg,`STATUS`,createUser,createUserName,createDt,correlation)
   VALUES(tenantId,signPackId,signServiceId,spPackId,spServiceId,spPackName,serviceId,serviceName,execUserId,patientName,'2',objId,doctorName,teamId,todayDate,serviceDesc,orgId,localOrgId,exeWay,source,'0','1',mpiId,createUserName,todayDate,'1'); 
   SELECT LAST_INSERT_ID() INTO serviceRecordId;  
   INSERT INTO ods_picturetextconsult(serviceRecordId,contentType,content,voiceImageFile,operaterType,operateUser,operateUserName,operateUserPicture,operateTime,targetType,targetUser,targetUserName,targetUserPicture,pictureFileIdString,readFlag)
   VALUES(serviceRecordId,contentType,serviceDesc,voiceImageFile,'041',execUserId,patientName,patientAvatar,todayDate,'031',doctorId,doctorName,doctorAvatar,pictureFileIdString,'0'); 
  END IF;    
  
  COMMIT; 
END;

