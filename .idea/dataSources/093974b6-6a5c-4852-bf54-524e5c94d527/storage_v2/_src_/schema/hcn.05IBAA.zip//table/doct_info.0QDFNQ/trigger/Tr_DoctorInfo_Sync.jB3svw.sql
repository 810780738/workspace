create trigger Tr_DoctorInfo_Sync
  after UPDATE
  on doct_info
  for each row
  BEGIN
     UPDATE base_pcn_team_doc SET docName=new.name WHERE docId = new.doctorId;
END;

