create view test_team as
  select
    `hcn`.`doct_info`.`doctorId`        AS `doctorId`,
    `hcn`.`doct_info`.`qrCode`          AS `qrCode`,
    `hcn`.`doct_info`.`name`            AS `name`,
    `hcn`.`doct_info`.`enName`          AS `enName`,
    `hcn`.`doct_info`.`sex`             AS `sex`,
    `hcn`.`doct_info`.`dob`             AS `dob`,
    `hcn`.`doct_info`.`idCard`          AS `idCard`,
    `hcn`.`doct_info`.`phoneNo`         AS `phoneNo`,
    `hcn`.`doct_info`.`nation`          AS `nation`,
    `hcn`.`doct_info`.`nationality`     AS `nationality`,
    `hcn`.`doct_info`.`email`           AS `email`,
    `hcn`.`doct_info`.`academic`        AS `academic`,
    `hcn`.`doct_info`.`major`           AS `major`,
    `hcn`.`doct_info`.`avatarFileId`    AS `avatarFileId`,
    `hcn`.`doct_info`.`introduce`       AS `introduce`,
    `hcn`.`doct_info`.`speciality`      AS `speciality`,
    `hcn`.`doct_info`.`summary`         AS `summary`,
    `hcn`.`doct_info`.`level`           AS `level`,
    `hcn`.`doct_info`.`certifiy`        AS `certifiy`,
    `hcn`.`doct_info`.`certifiyNo`      AS `certifiyNo`,
    `hcn`.`doct_info`.`certifiyAddress` AS `certifiyAddress`,
    `hcn`.`doct_info`.`certifiyScope`   AS `certifiyScope`,
    `hcn`.`doct_info`.`checkOrg`        AS `checkOrg`,
    `hcn`.`doct_info`.`mnemonic`        AS `mnemonic`,
    `hcn`.`doct_info`.`createDt`        AS `createDt`,
    `hcn`.`doct_info`.`createUser`      AS `createUser`,
    `hcn`.`doct_info`.`source`          AS `source`,
    `hcn`.`doct_info`.`lastModify`      AS `lastModify`,
    `hcn`.`doct_info`.`lastModifyUser`  AS `lastModifyUser`,
    `hcn`.`doct_info`.`ebUserName`      AS `ebUserName`,
    `hcn`.`doct_info`.`ebPassword`      AS `ebPassword`,
    `hcn`.`doct_info`.`status`          AS `status`,
    `hcn`.`doct_info`.`certificateHead` AS `certificateHead`,
    `hcn`.`doct_info`.`certificateBack` AS `certificateBack`,
    `hcn`.`doct_info`.`docType`         AS `docType`
  from `hcn`.`doct_info`
  where `hcn`.`doct_info`.`doctorId` in (select `hcn`.`base_pcn_team`.`teamLeaderId`
                                         from `hcn`.`base_pcn_team`
                                         where (`hcn`.`base_pcn_team`.`teamId` >= 61));

