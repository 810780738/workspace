create function getDoctorType(doctor_Id varchar(255))
  returns varchar(255)
  BEGIN
DECLARE doc_Type VARCHAR (255) ; SELECT
	docType INTO doc_Type
FROM
	doct_info
WHERE
	doctorId = doctor_Id ; RETURN doc_Type ;
END;

