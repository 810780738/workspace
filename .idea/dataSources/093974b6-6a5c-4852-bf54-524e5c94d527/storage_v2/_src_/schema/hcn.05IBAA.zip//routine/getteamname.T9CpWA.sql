create function getTeamName(team_Id bigint)
  returns varchar(255)
  BEGIN
DECLARE team_Name VARCHAR (255) ; SELECT
	teamName INTO team_Name
FROM
	base_pcn_team
WHERE
	teamId = team_Id ; RETURN team_Name ;
END;

