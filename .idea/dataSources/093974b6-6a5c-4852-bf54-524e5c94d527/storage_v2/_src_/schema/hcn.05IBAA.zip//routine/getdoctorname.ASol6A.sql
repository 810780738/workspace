create function getDoctorName(doctor_Id varchar(255))
  returns varchar(255)
  BEGIN
DECLARE doctor_Name VARCHAR (255) ; SELECT
	NAME INTO doctor_Name
FROM
	doct_info
WHERE
	doctorId = doctor_Id ; RETURN doctor_Name ;
END;

