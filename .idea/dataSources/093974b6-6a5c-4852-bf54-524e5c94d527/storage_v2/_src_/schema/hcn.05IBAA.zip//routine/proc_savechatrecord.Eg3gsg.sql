create procedure proc_saveChatRecord(IN  serviceRecordId     int, IN fromType char(3), IN fromId varchar(36),
                                     IN  toType              char(3), IN toId varchar(36), IN operateTime datetime,
                                     IN  content             varchar(500), IN contentType char(2),
                                     IN  voiceImageFile      int, IN pictureFileIdString varchar(100), OUT rtnCode int,
                                     OUT rtnMsg              varchar(100), OUT consultRecordId int)
  BEGIN
  DECLARE fromName VARCHAR(30);
  DECLARE fromAvatar INT; 
  DECLARE toName VARCHAR(30);
  DECLARE toAvatar INT; 
  DECLARE usedCount INT; 
  DECLARE serviceRecordState CHAR(1); 
  DECLARE flag INT; 
 
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
   SET rtnCode=100101;
   SET rtnMsg='数据库操作异常';
  END;
  SET flag=1;  
  SET rtnCode=1;
  SET rtnMsg='操作成功';
  
  SELECT ps.status INTO serviceRecordState FROM  pcn_service_exec ps WHERE ps.exeId=serviceRecordId;
  IF( serviceRecordState='8')
  THEN
   SET rtnCode=100012;
   SET rtnMsg='当前咨询服务已结束';
   SET flag=0;
  ELSE
   SET flag=1;
  END IF;  
   
  IF(flag=0)
  THEN  
    SET flag=0;
  ELSEIF(fromType='031')
  THEN
    SELECT md.personName,md.avatar INTO toName,toAvatar FROM mpi_demographicinfo md WHERE md.mpiId = toId;
    SELECT dt.name,dt.avatarFileId INTO fromName,fromAvatar FROM doct_info dt WHERE dt.doctorId = fromId;  
    SET serviceRecordState='2';
  ELSEIF(fromType='041')
  THEN
    SELECT md.personName,md.avatar INTO fromName,fromAvatar FROM mpi_demographicinfo md WHERE md.mpiId = fromId;
    SELECT dt.name,dt.avatarFileId INTO toName,toAvatar FROM doct_info dt WHERE dt.doctorId = toId; 
    SET serviceRecordState='1';
  END IF; 
  
  IF(flag=0)
  THEN  
   SET flag=0;
  ELSEIF (fromName IS NULL)
  THEN 
   SET rtnCode=100010;
   SET rtnMsg='发送者姓名为空';
   SET flag=0;
  ELSEIF(toName IS NULL)
  THEN 
   SET rtnCode=100011;
   SET rtnMsg='接收者姓名为空';
  SET flag=0;
  ELSE
   UPDATE pcn_service_exec SET `status` = serviceRecordState WHERE exeId=serviceRecordId;      
   INSERT INTO ods_picturetextconsult(serviceRecordId,contentType,content,voiceImageFile,operaterType,operateUser,operateUserName,operateUserPicture,operateTime,targetType,targetUser,targetUserName,targetUserPicture,pictureFileIdString,readFlag)
   VALUES(serviceRecordId,contentType,content,voiceImageFile,fromType,fromId,fromName,fromAvatar,operateTime,toType,toId,toName,toAvatar,pictureFileIdString,0);  
   SELECT LAST_INSERT_ID() INTO consultRecordId;  
  END IF;    
  COMMIT; 
END;

