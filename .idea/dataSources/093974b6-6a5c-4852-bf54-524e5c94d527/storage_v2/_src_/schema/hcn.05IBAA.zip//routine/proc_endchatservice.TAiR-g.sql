create procedure proc_endChatService(IN  serviceRecordId int, IN doctorId varchar(36), IN mpiId varchar(32),
                                     IN  memberId        varchar(32), IN operateTime datetime, OUT rtnCode int,
                                     OUT rtnMsg          varchar(100))
  BEGIN
  DECLARE personName VARCHAR(20);
  DECLARE endRole VARCHAR(7); 
  DECLARE signPackId INT; 
  DECLARE signServiceId INT; 
  DECLARE leftCount INT; 
 
  DECLARE flag INT; 
 
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
   SET rtnCode=100101;
   SET rtnMsg='数据库操作异常';
  END;
  SET flag=1;  
  SET rtnCode=1;
  SET rtnMsg='操作成功';
  
  
  IF( serviceRecordId IS NULL OR serviceRecordId=0)
  THEN
   SET flag=0;
   SET rtnCode=100016;
   SET rtnMsg='服务记录信息缺失';
  ELSEIF( doctorId <> '')
  THEN
   SELECT dt.name INTO personName FROM doct_info dt WHERE dt.doctorId=doctorId;
   SET endRole='doctor';
  ELSEIF (memberId <> '')
  THEN
   SELECT m.personName INTO personName FROM mpi_demographicinfo m WHERE m.mpiId=memberId;
   SET endRole='member';
  ELSEIF (mpiId <> '')
  THEN
   SELECT m.personName INTO personName FROM mpi_demographicinfo m WHERE m.mpiId=mpiId;
   SET endRole='patient';
  ELSE
   SET flag=0;
   SET rtnCode=100015;
   SET rtnMsg='操作人信息缺失';
  END IF;
    
  IF(flag=1)
  THEN
    UPDATE pcn_service_exec SET `status`='8',lastModifyUser=personName,lastModifyDt=operateTime WHERE exeId=serviceRecordId;    
  END IF;  
  SELECT ps.signPackId,ps.signServiceId INTO signPackId,signServiceId FROM pcn_service_exec ps WHERE ps.exeId=serviceRecordId; -- 查询签约服务包ID和签约服务项ID，用于更新签约服务包表和签约服务项的finished值为y(当签约服务向的remainTimes为0时)
  SELECT pss.remainTimes INTO leftCount FROM pcn_sign_service pss WHERE pss.signServiceId=signServiceId;
  IF( leftCount IS NULL OR leftCount=0)
  THEN
    UPDATE pcn_sign_service pss SET pss.finished='y' WHERE pss.signServiceId=signServiceId;
    UPDATE pcn_sign_resident_pack psrp SET psrp.finished='y' WHERE psrp.signPackId=signPackId; 
  END IF;
  COMMIT; 
END;

