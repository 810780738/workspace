create procedure proc_qryServiceRecordCount(IN  tenantId      varchar(32), IN targetType varchar(3),
                                            IN  targetId      varchar(36), IN participantId varchar(36),
                                            IN  stateText     varchar(36), OUT rtnCode int, OUT rtnMsg varchar(100),
                                            OUT rtnCount      int)
  BEGIN
 
  DECLARE flag INT; 
 
  DECLARE EXIT HANDLER FOR SQLEXCEPTION
  BEGIN
   SET rtnCode=100101;
   SET rtnMsg='数据库操作异常';
  END;
  SET flag=1;  
  SET rtnCode=1;
  SET rtnMsg='操作成功';
  
  
  IF(targetType ='')
  THEN
   SET flag=0;
   SET rtnCode=100017;
   SET rtnMsg='用户类型未指定';
  ELSEIF( targetId = '')
  THEN
   SET flag=0;
   SET rtnCode=100015;
   SET rtnMsg='操作人信息缺失';
  ELSEIF (targetType='031')
  THEN
   SELECT COUNT(1) INTO rtnCount FROM pcn_service_exec pe
   WHERE pe.tenantId=tenantId AND EXISTS(SELECT pd.memberId FROM pcn_team_member pd WHERE pd.teamId= pe.teamId AND pd.memberType='doctor' AND pd.memberObjId=targetId)
       AND stateText LIKE CONCAT('%',pe.status,',%') 
       AND ( participantId='' OR 
      (
        participantId<>'' AND 
        (pe.mpiId=participantId) 
       ) 
      );
  ELSEIF (targetType='041')
  THEN
   SELECT COUNT(1) INTO rtnCount FROM pcn_service_exec pe
   WHERE pe.tenantId=tenantId AND (pe.mpiId=targetId OR pe.createUser=targetId) AND stateText LIKE CONCAT('%',pe.status,',%') 
   AND pe.teamId IN (SELECT ps.teamId  FROM pcn_sign ps WHERE ps.mpiId=targetId AND (ps.isCancel IS NULL OR ps.isCancel <> '1') AND  DATEDIFF(NOW(), ps.beginDate) >= 0 ) -- 是否同一团队下的咨询记录
   AND (participantId ='' OR (
       participantId<>'' AND EXISTS(SELECT pd.memberId FROM pcn_team_member pd WHERE pd.teamId= pe.teamId AND pd.memberType='doctor' AND pd.memberObjId=participantId AND pe.exeUserId=pd.memberId)
     )
    );
  END IF;  
  COMMIT; 
END;

