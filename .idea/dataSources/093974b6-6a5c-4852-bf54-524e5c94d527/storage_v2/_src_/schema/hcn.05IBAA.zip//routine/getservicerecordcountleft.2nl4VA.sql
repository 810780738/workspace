create function getServiceRecordCountLeft(tenantId varchar(32), mpiId varchar(32), qryDate datetime)
  returns int
  BEGIN
 DECLARE serviceCount INT; 
 DECLARE startDate DATETIME;
 DECLARE endDate DATETIME;
 
  SELECT SUM(ps.remainTimes) INTO serviceCount
  FROM pcn_sign_service ps,pcn_sign_resident_pack pss 
  WHERE ps.signPackId=pss.signPackId AND pss.signId IN 
  (
          SELECT psn.signId
	  FROM pcn_sign psn
	  WHERE   psn.mpiId=mpiId AND psn.tenantId=tenantId AND qryDate BETWEEN psn.beginDate 
                AND psn.endDate AND (psn.isCancel IS NULL OR psn.isCancel <> '1')
  )
  AND ps.spServiceId IN (
   SELECT psv.spServiceId
   FROM pcn_sp_service psv
   WHERE psv.serviceId IN (
     SELECT bps.serviceId FROM pcn_base_service bps WHERE bps.isEnable=1 AND bps.correlation LIKE '%30%' AND tenantId=tenantId
   ) AND psv.isEnable=1
 
 );
RETURN serviceCount;
END;

